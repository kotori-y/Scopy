# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 16:51:25 2019

@Author: Zhi-Jiang Yang, Dong-Sheng Cao
@Institution: CBDD Group, Xiangya School of Pharmaceutical Science, CSU, China
@Homepage: http://www.scbdd.com
@Mail: yzjkid9@gmail.com; oriental-cds@163.com
@Blog: https://blog.moyule.me

"""

from scopy import ScoConfig
from rdkit.Chem import AllChem as Chem
import csv


def ComputeCrippen(mol):
    """
    """
    nAtom = len(mol.GetAtoms())
    doneAtoms = [0]*nAtom
    fps = [0]*110
    idx = -1
    flag = 0  
    found = 0
    with open(ScoConfig.CrippenDir + '\\Crippen.txt') as f_obj:
        lines = csv.reader(f_obj,delimiter='\t')
        next(lines)
        for line in lines:
            idx += 1
            count = 0
            patt = Chem.MolFromSmarts(line[1])
            for match in mol.GetSubstructMatches(patt):
                firstidx = match[0]
                if not doneAtoms[firstidx]:
                    doneAtoms[firstidx] = 1
                    count += 1
                    found += 1
                    if found >= nAtom:
                        flag = 1
                        break
            fps[idx] = count
            if flag:
                return fps
            
            
            
if '__main__' == __name__:
    smis = ['[O-]c1ccc2c(c1)oc(=O)c(c2)C(=O)C',
            'CCSc1nc2ccccc2c(=O)o1',
            'Cc1nc2ccccc2c(=O)o1',
            'CCN(c1ccc2c(c1)oc(=O)c(c2)C(=O)[O-])CC',
            'Cc1cccc2c1c(=O)oc(n2)C(F)(F)F',
            'CC(N(c1nc2ccccc2c(=O)o1)C(C)C)C'
            ]
    for smi in smis:
        mol = Chem.MolFromSmiles(smi)
        res = ComputeCrippen(mol)
        print(res)