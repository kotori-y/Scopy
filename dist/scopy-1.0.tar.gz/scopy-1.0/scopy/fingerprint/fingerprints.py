# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 21:59:42 2019

@Author: Zhi-Jiang Yang, Dong-Sheng Cao
@Institution: CBDD Group, Xiangya School of Pharmaceutical Science, CSU, China，
@Homepage: http://www.scbdd.com
@Mail: yzjkid9@gmail.com; oriental-cds@163.com
@Blog: https://blog.moyule.me

"""

import csv
from scopy import ScoConfig
from rdkit.Chem import AllChem as Chem
from scopy.StructureAlert import SmartProcess
from rdkit.Chem import MACCSkeys

from PubChemFingerprints import calcPubChemFingerAll


def CalculateEFG(mol,detail=False):
    res = SmartProcess._CheckWithSmarts(mol,endpoint='Extended_Functional_Groups')
    return res


def CalculateCrippen(mol):
    """
    """
    nAtom = len(mol.GetAtoms())
    doneAtoms = [0]*nAtom
    fps = [0]*110
    idx = -1
    flag = 0  
    found = 0
    with open(ScoConfig.CrippenDir + '\\Crippen.txt') as f_obj:
        lines = csv.reader(f_obj,delimiter='\t')
        next(lines)
        for line in lines:
            idx += 1
            count = 0
            patt = Chem.MolFromSmarts(line[1])
            for match in mol.GetSubstructMatches(patt):
                firstidx = match[0]
                if not doneAtoms[firstidx]:
                    doneAtoms[firstidx] = 1
                    count += 1
                    found += 1
                    if found >= nAtom:
                        flag = 1
                        break
            fps[idx] = count
            if flag:
                return ''.join([str(x) for x in fps])
            

def CalculateEstate(mol):
    """
    """
    res={}
    temp=EstateFingerprint(mol)
    for i in temp:
        if temp[i]>0:
            res[i[7:]]=1       
    return res



def CalculateMaccs(mol):
    """
    """
    fps = MACCSkeys.GenMACCSKeys(mol)
    return fps.ToBitString()

def CalculateFp4(mol):
    """
    """
    pass


def CalculatePubChemFingerprint(mol):
    """
    Calculate PubChem Fingerprints
    """
    res = calcPubChemFingerAll(mol)
    return res
 

if '__main__' == __name__:
    smi = 'C1=NC2NC3=CNCC3=CC2CC1'
    mol = Chem.MolFromSmiles(smi)
    res = CalculatePubChemFingerprint(mol)
    print(res)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

